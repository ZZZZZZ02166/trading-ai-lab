"""Offline tests: no network, a fake X API."""
import datetime
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "xconsensus"))
import fetch_posts as fp  # noqa: E402
import render  # noqa: E402

NOW = datetime.datetime(2026, 11, 11, 13, 0, tzinfo=datetime.timezone.utc)
CFG = {"max_posts_per_account": 10, "monthly_budget_usd": 10.0, "price_per_post_usd": 0.005,
       "first_run_lookback_hours": 24,
       "accounts": [{"handle": "Alice", "type": "opinion"}, {"handle": "bob", "type": "opinion", "max_posts": 3},
                    {"handle": "newsy", "type": "news"}]}


class FakeX:
    def __init__(self):
        self.calls = []
        self.timeline = {"1": [("101", "Long $NVDA into earnings"), ("100", "$AMD looks weak")], "2": [("200", "Buying $NVDA")], "3": []}

    def __call__(self, path, params):
        self.calls.append((path, dict(params)))
        if path == "/users/by":
            ids = {"alice": "1", "bob": "2", "newsy": "3"}
            return {"data": [{"username": u, "id": ids[u.lower()]} for u in params["usernames"].split(",")]}
        uid = path.split("/")[2]
        rows = [r for r in self.timeline[uid] if int(r[0]) > int(params.get("since_id", 0))]
        data = [{"id": i, "text": t, "created_at": "2026-11-11T12:00:00Z",
                 "entities": {"cashtags": [{"tag": w[1:]} for w in t.split() if w.startswith("$")]}} for i, t in rows]
        return {"data": data, "meta": {"newest_id": rows[0][0]} if rows else {}}


class TestFetch(unittest.TestCase):
    def test_fetch_dedup_cap_and_cost(self):
        x, state, usage = FakeX(), {}, {}
        posts = fp.run(CFG, state, usage, NOW, x, log=lambda *_: None)
        self.assertEqual(len(posts), 3)
        self.assertEqual(posts[0]["cashtags"], ["NVDA"])
        self.assertEqual(posts[0]["url"], "https://x.com/Alice/status/101")
        tl = [c for c in x.calls if c[0].endswith("/tweets")]
        self.assertTrue(all(c[1]["exclude"] == "replies,retweets" for c in tl))
        self.assertEqual(tl[1][1]["max_results"], 5)          # cap 3 is raised to the API minimum of 5
        self.assertIn("start_time", tl[0][1])                 # first run looks back 24h
        m = usage["2026-11"]
        self.assertEqual((m["posts"], m["lookups"]), (3, 3))
        self.assertAlmostEqual(m["usd"], 3 * 0.005 + 3 * 0.01)
        # second run: nothing new, no second id lookup, uses since_id
        x.calls.clear()
        self.assertEqual(fp.run(CFG, state, usage, NOW, x, log=lambda *_: None), [])
        self.assertFalse([c for c in x.calls if c[0] == "/users/by"])
        self.assertEqual(x.calls[0][1]["since_id"], "101")
        self.assertEqual(usage["2026-11"]["posts"], 3)

    def test_budget_guard_stops_reading(self):
        x, state = FakeX(), {"ids": {"alice": "1", "bob": "2", "newsy": "3"}}
        usage = {"2026-11": {"posts": 2000, "lookups": 0, "usd": 10.0}}
        self.assertEqual(fp.run(CFG, state, usage, NOW, x, log=lambda *_: None), [])
        self.assertEqual(x.calls, [])


class TestRender(unittest.TestCase):
    def test_consensus_groups(self):
        posts = {str(i): {"post_id": str(i), "handle": h, "created_at": "2026-11-11T1%d:00:00Z" % i, "url": "u"}
                 for i, h in enumerate(["a", "b", "c", "newsy", "a"])}
        L = lambda pid, h, s, st: {"post_id": pid, "handle": h, "symbol": s, "stance": st}
        labels = [L("0", "a", "NVDA", "bearish"), L("4", "a", "NVDA", "bullish"),   # a changed its mind: latest wins
                  L("1", "b", "NVDA", "bullish"),
                  L("1", "b", "TSLA", "bullish"), L("2", "c", "TSLA", "bearish"),
                  L("2", "c", "AMD", "bullish"), L("3", "newsy", "AMD", "bullish")]  # news account does not count
        sb, sbe, sp, other = render.build(posts, labels, {"newsy": "news"})
        self.assertEqual([r[0] for r in sb], ["NVDA"])
        self.assertEqual(sbe, [])
        self.assertEqual([r[0] for r in sp], ["TSLA"])
        self.assertEqual([r[0] for r in other], ["AMD"])


if __name__ == "__main__":
    unittest.main()
