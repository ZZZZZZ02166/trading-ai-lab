# trading-alert-bot

Part 1: X consensus tracker. Reads new posts from the accounts in `config/accounts.json`
once a day, then builds a bullish / bearish / split dashboard.

## Setup (once)
1. Get an X API bearer token at https://developer.x.com and load a small credit (e.g. $10).
2. Copy `config/.env.example` to `config/.env` and paste the token in.

## Daily run
```bash
python3 xconsensus/fetch_posts.py --dry-run   # shows the most today could cost
python3 xconsensus/fetch_posts.py             # saves data/posts/DATE.json
# Claude labels the posts following LABELING.md -> data/labels/DATE.json
python3 xconsensus/render.py                  # reports/consensus-DATE.html
python3 xconsensus/render.py --days 7         # weekly view
```

## Cost controls (config/accounts.json)
- `max_posts_per_account`: cap per account per run (the API minimum is 5). Per-account `max_posts` overrides it.
- `monthly_budget_usd`: reading stops for the month once this is reached.
- Replies and reposts are never requested. Each post is fetched once only.
- Spend is tracked in `data/usage.json` using `price_per_post_usd`; check it against your X billing page.

## Tests
```bash
python3 -m unittest discover -s tests
```

Needs Python 3.8+. No packages to install. Not investment advice.
