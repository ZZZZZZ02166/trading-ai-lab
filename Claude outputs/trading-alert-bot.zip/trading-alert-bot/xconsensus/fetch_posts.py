"""Fetch new original posts (no replies, no reposts) from the tracked X accounts.

Usage:
  python3 xconsensus/fetch_posts.py            # fetch and save
  python3 xconsensus/fetch_posts.py --dry-run  # show what would be requested, no API calls

Writes data/posts/YYYY-MM-DD.json (UTC date of the run) and keeps
data/state.json (account ids, last post seen) and data/usage.json (spend).
Each post is only ever fetched once: the next run starts after the last post seen.
"""
import argparse
import datetime
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CONFIG, DATA, bearer_token, load_json, save_json  # noqa: E402

API = "https://api.x.com/2"
STATE = os.path.join(DATA, "state.json")
USAGE = os.path.join(DATA, "usage.json")
LOOKUP_PRICE = 0.01  # one-off cost per account id lookup


def api_get(path, params, token):
    url = "%s%s?%s" % (API, path, urllib.parse.urlencode(params))
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token,
                                               "User-Agent": "trading-alert-bot"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:300]
        raise RuntimeError("X API %s for %s: %s" % (e.code, path, body))


def month_key(now):
    return now.strftime("%Y-%m")


def spent_this_month(usage, now):
    return usage.get(month_key(now), {}).get("usd", 0.0)


def add_usage(usage, now, posts=0, lookups=0, price=0.005):
    m = usage.setdefault(month_key(now), {"posts": 0, "lookups": 0, "usd": 0.0})
    m["posts"] += posts
    m["lookups"] += lookups
    m["usd"] = round(m["usd"] + posts * price + lookups * LOOKUP_PRICE, 4)


def resolve_ids(cfg, state, usage, now, get):
    """Look up numeric ids for handles we have not seen before (one-off)."""
    ids = state.setdefault("ids", {})
    missing = [a["handle"] for a in cfg["accounts"] if a["handle"].lower() not in ids]
    if not missing:
        return
    data = get("/users/by", {"usernames": ",".join(missing)})
    for u in data.get("data", []):
        ids[u["username"].lower()] = u["id"]
    add_usage(usage, now, lookups=len(data.get("data", [])))
    for err in data.get("errors", []):
        print("  warning: could not find @%s (%s)" % (err.get("value"), err.get("title")))


def post_text(p):
    # Long posts keep their full text in note_tweet.
    return (p.get("note_tweet") or {}).get("text") or p.get("text", "")


def fetch_account(acct, cfg, state, now, get):
    handle = acct["handle"]
    uid = state["ids"].get(handle.lower())
    if not uid:
        return []
    cap = int(acct.get("max_posts", cfg["max_posts_per_account"]))
    cap = max(5, min(cap, 100))  # the API accepts 5..100 per request
    params = {"max_results": cap, "exclude": "replies,retweets",
              "tweet.fields": "created_at,lang,public_metrics,entities,note_tweet"}
    since = state.setdefault("since_id", {}).get(handle.lower())
    if since:
        params["since_id"] = since
    else:
        start = now - datetime.timedelta(hours=cfg["first_run_lookback_hours"])
        params["start_time"] = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    data = get("/users/%s/tweets" % uid, params)
    out = []
    for p in data.get("data", []):
        tags = [c["tag"].upper() for c in (p.get("entities") or {}).get("cashtags", [])]
        out.append({"post_id": p["id"], "handle": handle, "name": acct.get("name", handle),
                    "account_type": acct.get("type", "opinion"),
                    "created_at": p.get("created_at"), "lang": p.get("lang"),
                    "text": post_text(p), "cashtags": sorted(set(tags)),
                    "likes": (p.get("public_metrics") or {}).get("like_count"),
                    "url": "https://x.com/%s/status/%s" % (handle, p["id"])})
    newest = (data.get("meta") or {}).get("newest_id")
    if newest:
        state["since_id"][handle.lower()] = newest
    return out


def run(cfg, state, usage, now, get, log=print):
    budget = float(cfg["monthly_budget_usd"])
    price = float(cfg["price_per_post_usd"])
    resolve_ids(cfg, state, usage, now, get)
    posts, skipped = [], []
    for acct in cfg["accounts"]:
        if spent_this_month(usage, now) >= budget:
            skipped.append(acct["handle"])
            continue
        try:
            got = fetch_account(acct, cfg, state, now, get)
        except RuntimeError as e:
            log("  error @%s: %s" % (acct["handle"], e))
            continue
        add_usage(usage, now, posts=len(got), price=price)
        posts.extend(got)
        log("  @%-16s %d new" % (acct["handle"], len(got)))
    if skipped:
        log("  BUDGET REACHED ($%.2f): skipped %s" % (budget, ", ".join(skipped)))
    return posts


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    cfg = load_json(CONFIG)
    now = datetime.datetime.now(datetime.timezone.utc)
    state = load_json(STATE, {})
    usage = load_json(USAGE, {})

    if args.dry_run:
        worst = sum(max(5, int(a.get("max_posts", cfg["max_posts_per_account"])))
                    for a in cfg["accounts"])
        print("Would read up to %d posts from %d accounts (max $%.2f today)."
              % (worst, len(cfg["accounts"]), worst * cfg["price_per_post_usd"]))
        print("Spent this month so far: $%.2f of $%.2f budget."
              % (spent_this_month(usage, now), cfg["monthly_budget_usd"]))
        return 0

    token = bearer_token()
    if not token:
        print("No X bearer token. Copy config/.env.example to config/.env and paste it in.")
        return 2
    posts = run(cfg, state, usage, now, lambda p, q: api_get(p, q, token))
    day = now.strftime("%Y-%m-%d")
    path = os.path.join(DATA, "posts", day + ".json")
    old = load_json(path, {"posts": []})["posts"]  # a second run the same day adds to the file
    seen = {p["post_id"] for p in old}
    merged = old + [p for p in posts if p["post_id"] not in seen]
    save_json(path, {"date": day, "fetched_at": now.isoformat(), "posts": merged})
    save_json(STATE, state)
    save_json(USAGE, usage)
    print("Saved %d new posts (%d today) to %s" % (len(posts), len(merged), path))
    print("Spent this month: $%.2f of $%.2f budget."
          % (spent_this_month(usage, now), cfg["monthly_budget_usd"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
