"""Build the consensus dashboard (HTML + a short text summary) from posts and labels.

Usage:
  python3 xconsensus/render.py                 # today (UTC), daily view
  python3 xconsensus/render.py --date 2026-11-11 --days 7   # rolling 7-day view
"""
import argparse
import collections
import datetime
import html
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CONFIG, DATA, REPORTS, load_json  # noqa: E402

STANCES = ("bullish", "bearish", "unclear")


def load_window(end, days):
    posts, labels = {}, []
    for i in range(days):
        day = (end - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
        for p in (load_json(os.path.join(DATA, "posts", day + ".json"), {}) or {}).get("posts", []):
            posts[p["post_id"]] = p
        for l in (load_json(os.path.join(DATA, "labels", day + ".json"), {}) or {}).get("labels", []):
            if l.get("stance") in STANCES and l.get("symbol") and l.get("post_id") in posts:
                labels.append(l)
    return posts, labels


def build(posts, labels, types):
    """Per symbol, each account's latest stance. Only opinion accounts count toward consensus."""
    by_symbol = collections.defaultdict(dict)
    for l in sorted(labels, key=lambda x: posts[x["post_id"]].get("created_at") or ""):
        by_symbol[l["symbol"].upper()][l["handle"]] = l  # later posts overwrite earlier ones
    shared_bull, shared_bear, split, other = [], [], [], []
    for sym, views in by_symbol.items():
        op = [v for h, v in views.items() if types.get(h.lower(), "opinion") == "opinion"]
        bull = [v for v in op if v["stance"] == "bullish"]
        bear = [v for v in op if v["stance"] == "bearish"]
        row = (sym, views, len(bull), len(bear))
        if bull and bear:
            split.append(row)
        elif len(bull) >= 2:
            shared_bull.append(row)
        elif len(bear) >= 2:
            shared_bear.append(row)
        else:
            other.append(row)
    key = lambda r: (-(r[2] + r[3]), r[0])
    return sorted(shared_bull, key=key), sorted(shared_bear, key=key), sorted(split, key=key), sorted(other, key=key)


def text_summary(title, groups, n_posts, n_accounts):
    sb, sbe, sp, other = groups
    fmt = lambda rows: ", ".join("%s (%d bull/%d bear)" % (r[0], r[2], r[3]) for r in rows) or "none"
    lines = [title, "Posts read: %d from %d accounts that posted" % (n_posts, n_accounts),
             "Shared bullish (2+ opinion accounts): " + fmt(sb),
             "Shared bearish (2+ opinion accounts): " + fmt(sbe),
             "Bull/bear split: " + fmt(sp),
             "Single-account or unclear mentions: " + (", ".join(r[0] for r in other) or "none")]
    return "\n".join(lines)


CSS = """body{font:15px/1.45 -apple-system,Segoe UI,sans-serif;margin:24px auto;max-width:980px;padding:0 16px;color:#1c1c1c;background:#faf9f5}
h1{font-size:26px;margin:0 0 4px}h2{font-size:18px;margin:28px 0 8px}.sub{color:#666;margin:0 0 8px}
.card{background:#fff;border:1px solid #e3e0d6;border-radius:10px;padding:12px 14px;margin:8px 0}
.sym{font-weight:700;font-size:18px;margin-right:8px}.v{margin:4px 0}.tag{font-weight:600;padding:1px 7px;border-radius:9px;font-size:12px}
.bullish{background:#dff3e4;color:#16602b}.bearish{background:#fbe1dd;color:#9a2415}.unclear{background:#ececec;color:#555}
a{color:#2b4fa8;text-decoration:none}.empty{color:#777;font-style:italic}
@media(prefers-color-scheme:dark){body{background:#181816;color:#e8e6df}.card{background:#22221f;border-color:#3a3a35}.sub,.empty{color:#aaa}a{color:#8fb0ff}
.bullish{background:#1d4428;color:#b9ecc6}.bearish{background:#5a221a;color:#ffc9c0}.unclear{background:#3a3a3a;color:#ccc}}"""


def section(title, note, rows, posts, names):
    e = html.escape
    out = ["<h2>%s</h2><p class='sub'>%s</p>" % (e(title), e(note))]
    if not rows:
        out.append("<p class='empty'>None in this window.</p>")
    for sym, views, nb, nbe in rows:
        out.append("<div class='card'><span class='sym'>%s</span>%d bullish · %d bearish" % (e(sym), nb, nbe))
        for h, v in sorted(views.items(), key=lambda kv: STANCES.index(kv[1]["stance"])):
            p = posts[v["post_id"]]
            out.append("<div class='v'><span class='tag %s'>%s</span> <b>%s</b> %s "
                       "<a href='%s' target='_blank' rel='noopener'>post ↗</a> <span class='sub'>%s</span></div>"
                       % (v["stance"], v["stance"], e(names.get(h.lower(), h)), e(v.get("reason", "")),
                          e(p["url"]), e((p.get("created_at") or "")[:10])))
        out.append("</div>")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--date", default=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d"))
    ap.add_argument("--days", type=int, default=1)
    a = ap.parse_args()
    end = datetime.datetime.strptime(a.date, "%Y-%m-%d")
    cfg = load_json(CONFIG)
    types = {x["handle"].lower(): x.get("type", "opinion") for x in cfg["accounts"]}
    names = {x["handle"].lower(): x.get("name", x["handle"]) for x in cfg["accounts"]}
    posts, labels = load_window(end, a.days)
    if not posts:
        print("No posts found for %s (last %d day/s). Run fetch_posts.py first." % (a.date, a.days))
        return 1
    groups = build(posts, labels, types)
    posted = {p["handle"] for p in posts.values()}
    title = "X consensus · %s" % (a.date if a.days == 1 else "%d days to %s" % (a.days, a.date))
    summary = text_summary(title, groups, len(posts), len(posted))
    quiet = [names[h] for h in names if h not in {p.lower() for p in posted}]
    body = ["<h1>%s</h1><p class='sub'>%d posts from %d of %d accounts. Labels are AI-inferred and can be wrong. Not investment advice.</p>"
            % (html.escape(title), len(posts), len(posted), len(names))]
    if not labels:
        body.append("<p class='empty'>Posts are fetched but not labelled yet (see LABELING.md).</p>")
    body.append(section("Clear shared bullish view", "At least 2 opinion accounts bullish, none bearish", groups[0], posts, names))
    body.append(section("Clear shared bearish view", "At least 2 opinion accounts bearish, none bullish", groups[1], posts, names))
    body.append(section("Bull/bear disagreement", "Opinion accounts on both sides", groups[2], posts, names))
    body.append(section("Other mentions", "One account only, or no clear stance", groups[3], posts, names))
    if quiet:
        body.append("<h2>No posts in this window</h2><p class='sub'>%s</p>" % html.escape(", ".join(quiet)))
    os.makedirs(REPORTS, exist_ok=True)
    name = "consensus-%s%s.html" % (a.date, "" if a.days == 1 else "-%dd" % a.days)
    path = os.path.join(REPORTS, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("<!doctype html><html lang='en'><head><meta charset='utf-8'>"
                 "<meta name='viewport' content='width=device-width,initial-scale=1'><title>%s</title><style>%s</style></head><body>%s</body></html>"
                 % (html.escape(title), CSS, "\n".join(body)))
    print(summary)
    print("Dashboard: " + path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
