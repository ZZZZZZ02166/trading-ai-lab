"""Shared helpers: paths, config, .env loading, JSON read/write."""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "config", "accounts.json")
ENV = os.path.join(ROOT, "config", ".env")
DATA = os.path.join(ROOT, "data")
REPORTS = os.path.join(ROOT, "reports")


def load_json(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    os.replace(tmp, path)


def bearer_token():
    tok = os.environ.get("X_BEARER_TOKEN", "").strip()
    if not tok and os.path.exists(ENV):
        with open(ENV, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("X_BEARER_TOKEN="):
                    tok = line.split("=", 1)[1].strip().strip('"').strip("'")
    return tok
